package com.telecom.mphasis.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.telecom.mphasis.entity.Customer;
import com.telecom.mphasis.entity.User;

public interface CustomerRepository extends JpaRepository<Customer, Long> {
	
	List<Customer> findByUser(User user);

}

