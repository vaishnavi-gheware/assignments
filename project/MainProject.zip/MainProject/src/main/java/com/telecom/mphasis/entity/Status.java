package com.telecom.mphasis.entity;

public enum Status {

	RAISED, ASSIGNED, WIP, RESOLVED, ESCALATED;
}
