package com.telecom.mphasis.dto;

import java.util.Set;

import com.telecom.mphasis.entity.User;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CustomerDto {
	
	
	private Long id;	
	private User user;
	private Set<String> serviceType;
	private String address;
	private String zipcode;
	public User getUser() {
		// TODO Auto-generated method stub
		return null;
	}
	public Set<String> getServiceType() {
		// TODO Auto-generated method stub
		return null;
	}
	public String getAddress() {
		// TODO Auto-generated method stub
		return null;
	}
	public String getZipcode() {
		// TODO Auto-generated method stub
		return null;
	}

	
}

