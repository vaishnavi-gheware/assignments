package com.telecom.mphasis.entity;

public enum ServiceType {

	LANDLINE, MOBILE, FIBER_OPTIC;
}

