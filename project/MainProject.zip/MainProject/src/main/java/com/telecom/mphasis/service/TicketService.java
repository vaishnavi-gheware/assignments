package com.telecom.mphasis.service;

import java.util.List;

import com.telecom.mphasis.entity.Feedback;
import com.telecom.mphasis.entity.Notes;
import com.telecom.mphasis.entity.Ticket;

public interface TicketService {

	String save(Ticket ticket);

	List<Ticket> getAllTickets();

	List<Ticket> getTicketsByCustomerId(Long id);

	Ticket getTicketById(Long id);

	List<Notes> getNotesByTicketId(Long id);

	String saveNotes(Notes notes);
	
	String saveFeedback(Feedback feedback);
	
	Feedback findFeedbackByTicket(Long id);
	
} 

