package com.telecom.mphasis.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.telecom.mphasis.entity.Feedback;
import com.telecom.mphasis.entity.Ticket;

public interface FeedbackRepository extends JpaRepository<Feedback, Long> {

	
	List<Feedback> findByTicket(Ticket ticket);
	
}

